<div>
    <nav class="navbar navbar-expand bg-dark navbar-dark fixed-bottom text-info">
        <strong class="text-center">
                &copy; <b>CRM</b> - Clientes Potenciales <?php echo date("Y");?> ®
        </strong>
    </nav>
</div>
</body>
</html>