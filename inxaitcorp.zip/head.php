<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRM - Clientes Potenciales</title>
    <?php
    include "script.php"; 
    include "controladores/conexion.php";
    ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body{
                  margin-left: 20%;
                  margin-top: 5%;
                  margin-right: 20%;
                  background-color: #F2F3F4;
                  padding-top: 50px;
                  padding-bottom: 50px;
            }
    </style>

</head>
<body>