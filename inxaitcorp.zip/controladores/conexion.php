<?php
$conn = new mysqli('localhost', 'root', '', 'inxaitcorp') or die(mysqli_error());
?>