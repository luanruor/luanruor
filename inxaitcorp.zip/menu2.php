<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
    <a class="navbar-brand" href="#">CRM</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    Inicio
                    <span class="sr-only">(current)</span>
                </a>
            </li>
            <li>
                <label class="text-info nav-link">
                    Bienvenid@ <?php echo "<b>".utf8_encode($nombres)." ".utf8_encode($apellidos)."</b>"; ?>
                </label>
            </li>
            <li>
                <a href="controladores/logout.php" class="btn btn-danger float-right">
                    Cerrar Sesi&oacute;n
                </a>
            </li>
        </ul>
    </div>
</nav>